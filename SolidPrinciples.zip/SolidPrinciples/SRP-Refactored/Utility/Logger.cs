﻿using System;

namespace SRP_Refactored.Utility
{
    public static class Logger
    {
        public static void Error(string message, Exception exception)
        {
            throw new NotImplementedException();
        }
    }
}