namespace OCP.Model.Refactored
{
    public interface IPricingCalculator
    {
        decimal CalculatePrice(OrderItem item);
    }
}