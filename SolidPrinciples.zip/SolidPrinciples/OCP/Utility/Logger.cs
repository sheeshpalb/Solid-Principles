﻿using System;

namespace OCP.Utility
{
    public static class Logger
    {
        public static void Error(string message, Exception exception)
        {
            throw new NotImplementedException();
        }
    }
}