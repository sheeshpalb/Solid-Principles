﻿using System;

namespace SRP.Utility
{
    public static class Logger
    {
        public static void Error(string message, Exception exception)
        {
            throw new NotImplementedException();
        }
    }
}