using System;

namespace DIP.Utility
{
    public static class Logger
    {
        public static void Error(string message, Exception exception)
        {
        }
    }
}